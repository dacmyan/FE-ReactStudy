import { authApi } from "@/features/auth/service";
import { queryClient } from "@/lib/queryClient";
import { useAuthStore } from "@/features/auth/store";
import { useMutation } from "@tanstack/react-query";
import { useLocation, useNavigate } from "react-router-dom"
import { toast } from "sonner";

export const useLoginMutation = () => {

  const location = useLocation();
  const navigate = useNavigate();
  const setTokens = useAuthStore((state) => state.setTokens);

  return useMutation({

    mutationFn: (
      useData: {
        email: string;
        password: string;
      }
    ) => authApi.login(useData),

    onSuccess: (response) => {

      setTokens(response.accessToken, response.refreshToken);

      toast.success("Đăng nhập thành công");

      const redirectPath = location.state?.from;
      navigate(redirectPath, { replace: true })

    },

    onError: (error: any) => {
      toast.error(
        error.response?.data?.message || "Đăng nhập thất bại. Vui lòng thử lại."
      );
    },

    onSettled: () => {
      // Có thể dùng để reset form hoặc thực hiện các hành động khác sau khi mutation hoàn thành (thành công hoặc thất bại)
    }

  })

}

export const useRegisterMutation = () => {
  const navigate = useNavigate();

  return useMutation({

    mutationFn: (userData: {
      fullName: string;
      email: string;
      password: string;
    }) => authApi.register(userData),

    onSuccess: () => {
      toast.success("Đăng ký thành công", {
        description: "Bạn đã có thể đăng nhập ngay bây giờ",
      });

      navigate("/login");
    },

    onError: (error: any) => {
      toast.error(
        error.response?.data?.message || "Đăng ký thất bại. Vui lòng thử lại."
      );
    },

    onSettled: () => {
      // Có thể dùng để reset form hoặc thực hiện các hành động khác sau khi mutation hoàn thành (thành công hoặc thất bại)
    }
  })
}

export const useLogoutMutation = () => {

  const clearTokens = useAuthStore().clearTokens

  return useMutation({

    mutationFn: () => authApi.logOut(),

    onSuccess: () => {
      clearTokens();

      //xóa cái cache của user đi, để khi vào lại trang profile sẽ bị redirect về login
      queryClient.removeQueries();

      // làm cái data cũ
      // queryClient.invalidateQueries();

      //xóa cụ thể 1 cái key
      // xài cho mấy cái CRUD
      // queryClient.invalidateQueries({ queryKey: ["me"] });
      toast.success("Đăng xuất thành công");
    },

    onError: () => {
      clearTokens();
      queryClient.removeQueries();
      // queryClient.invalidateQueries({ queryKey: ["me"] });
      toast.success("Đăng xuất thành công");
    }
  })
}