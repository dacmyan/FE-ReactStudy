import { createBrowserRouter } from "react-router-dom";
import MainLayout from "@/shared/layouts/MainLayout";
import HomePage from "@/shared/pages/HomePage";
import LoginPage from "@/features/auth/pages/LoginPage";
import RequireAuth from "@/shared/common/guards/RequireAuth";
import RequireUnauth from "@/shared/common/guards/RequireUnAuth";
import ProfilePage from  "@/features/auth/pages/ProfilePage";
import SettingsPage from "@/features/auth/pages/SettingPage";
import RegisterPage from "@/features/auth/pages/RegisterPage";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />, // Layout bọc ngoài (Cái nhà)
    children: [
      // Các trang con (Nội thất)
      {
        index: true,
        element: <HomePage />,
      },
      {
        element: <RequireUnauth />,
        children: [
          {
            path: "login",
            element: <LoginPage />,
          },
          {
            path: "register",
            element: <RegisterPage />, // Tạm thời dùng RegisterPage cho demo, sau này sẽ tạo RegisterPage riêng
          },
        ],
      },
      {
        element: <RequireAuth />,
        children: [
          { path: "profile", element: <ProfilePage /> },
          { path: "settings", element: <SettingsPage /> },
        ],
      },
    ],
  },
]);
