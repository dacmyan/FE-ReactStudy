//xử lý dịch vụ liên quan tới auth
//login, register, logout, get...

import { apiClient } from "@/lib/axios";

interface AuthToken {
  accessToken: string;
  refreshToken: string;
}

interface LoginSchemaType {
  email: string;
  password: string;
}

interface RegisterSchemaType {
  fullName: string;
  email: string;
  password: string;
}

interface UserInfo {
  _id: string;
  fullName: string;
  email: string;
}
export const authApi = {

  //login
  async login(credentials: LoginSchemaType): Promise<AuthToken> {
    //gọi api
    const { data } = await apiClient.post("/auth/login", credentials);
    return {
      accessToken: data.accessToken,
      refreshToken: data.refreshToken,
    }
  },

  //register
  async register(credentials: RegisterSchemaType): Promise<AuthToken> {
    return await apiClient.post("/auth/register", credentials);
  },

  //logout
  async logOut(): Promise<void> {
    await apiClient.post("/auth/logout");
  },

  //get user info
  async getUserInfo(): Promise<UserInfo> {
    const { data } = await apiClient.get("/auth/me");
    return {
      _id: data.id,
      email: data.email,
      fullName: data.fullName,
    }
  }
}