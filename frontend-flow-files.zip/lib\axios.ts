// tạo ra apiCLient để gọi API
//interceptor(request, response)
//request: tự thêm token vào header
//response: tự động bắt lỗi và request token flow

import axios from "axios";
import { env } from "./env";

export const apiClient = axios.create({
  baseURL: env.API_URL,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 3000,
  withCredentials: true,
})
