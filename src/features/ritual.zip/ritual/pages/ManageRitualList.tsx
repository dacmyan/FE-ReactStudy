import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { useRitualCatalog } from "@/features/ritual/hooks/useRitualCatalog";
import { useRitualCategories } from "@/features/ritual/hooks/useRitualCategories";
import { ritualService } from "@/features/auth/service";
import { LoadingState, ErrorState } from "@/shared/components/states/StatusState";
import { Button } from "@/shared/components/ui/button";
import { Input } from "@/shared/components/ui/input";
import { Card, CardContent } from "@/shared/components/ui/card";
import { toast } from "sonner";
import {
    Plus,
    Search,
    Edit,
    Trash2,
    Eye,
    Sparkles,
    ChevronLeft,
    ChevronRight,
    Flame
} from "lucide-react";

const ManageRitualList: React.FC = () => {
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    // Admin filter states
    const [search, setSearch] = useState("");
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const [selectedCategoryId, setSelectedCategoryId] = useState("all");
    const [selectedDifficulty, setSelectedDifficulty] = useState("all");
    const [page, setPage] = useState(1);
    const limit = 8; // Row items per page in admin table

    // Debounce search input
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedSearch(search);
            setPage(1);
        }, 450);
        return () => clearTimeout(handler);
    }, [search]);

    // Fetch Categories
    const { data: categoriesData } = useRitualCategories();
    const categories = categoriesData?.data || [];

    // Fetch Rituals List for admin
    const queryParams = {
        page,
        limit,
        search: debouncedSearch || undefined,
        ritualCategoryId: selectedCategoryId === "all" ? undefined : selectedCategoryId,
        difficultLevel: selectedDifficulty === "all" ? undefined : selectedDifficulty.toLowerCase(),
    };

    const { data: catalogData, isLoading, error, refetch } = useRitualCatalog(queryParams);
    const rituals = catalogData?.data || [];
    const meta = catalogData?.meta;
    const totalPages = meta?.totalPages || 1;

    // Delete Mutation
    const deleteMutation = useMutation({
        mutationFn: (id: string) => ritualService.remove(id),
        onSuccess: () => {
            toast.success("Xóa nghi lễ thành công");
            // Refetch catalog lists
            queryClient.invalidateQueries({ queryKey: ["ritualCatalog"] });
            queryClient.invalidateQueries({ queryKey: ["rituals"] });
        },
        onError: (err: any) => {
            const msg = err?.response?.data?.message || "Không thể xóa nghi lễ. Vui lòng thử lại.";
            toast.error(msg);
        },
    });

    const handleDelete = (id: string, name: string) => {
        if (window.confirm(`Bạn có chắc chắn muốn xóa nghi lễ "${name}" không? Hành động này không thể hoàn tác.`)) {
            deleteMutation.mutate(id);
        }
    };

    const getDifficultyColor = (level: string) => {
        const norm = level.toLowerCase().trim();
        if (norm === "dễ") return "bg-emerald-50 text-emerald-700 border-emerald-200";
        if (norm === "trung bình") return "bg-amber-50 text-amber-700 border-amber-200";
        if (norm === "khó") return "bg-orange-50 text-orange-700 border-orange-200";
        return "bg-rose-50 text-rose-700 border-rose-200";
    };

    const handlePageChange = (newPage: number) => {
        if (newPage >= 1 && newPage <= totalPages) {
            setPage(newPage);
        }
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-300">

            {/* Admin Panel Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-foreground/5 pb-4">
                <div>
                    <h1 className="text-2xl font-extrabold font-serif text-slate-900 tracking-tight flex items-center gap-2">
                        <Sparkles className="w-6 h-6 text-amber-600" />
                        Quản Lý Danh Sách Nghi Lễ
                    </h1>
                    <p className="text-muted-foreground text-sm">
                        Xem, thêm mới, điều chỉnh thông tin hoặc gỡ bỏ các nghi lễ hệ thống.
                    </p>
                </div>

                <Button
                    onClick={() => navigate("/admin/rituals/create")}
                    className="bg-amber-600 hover:bg-amber-700 text-white font-semibold flex items-center gap-2 shadow-md shadow-amber-600/10 self-start sm:self-auto"
                >
                    <Plus className="w-4 h-4" />
                    Thêm Nghi Lễ Mới
                </Button>
            </div>

            {/* Filter and Search Bar */}
            <Card className="border border-foreground/5 shadow-sm">
                <CardContent className="pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">

                        {/* Search Input */}
                        <div className="md:col-span-2 relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                            <Input
                                type="text"
                                placeholder="Tìm tên nghi lễ..."
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                                className="pl-9 bg-white"
                            />
                        </div>

                        {/* Category Dropdown */}
                        <div>
                            <select
                                value={selectedCategoryId}
                                onChange={(e) => { setSelectedCategoryId(e.target.value); setPage(1); }}
                                className="w-full h-9 px-3 bg-white border border-input rounded-md text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-amber-500 focus:border-amber-500 font-medium"
                            >
                                <option value="all">Tất cả phân loại</option>
                                {categories.map((cat) => (
                                    <option key={cat.id} value={cat.id}>
                                        {cat.name}
                                    </option>
                                ))}
                            </select>
                        </div>

                        {/* Difficulty Dropdown */}
                        <div>
                            <select
                                value={selectedDifficulty}
                                onChange={(e) => { setSelectedDifficulty(e.target.value); setPage(1); }}
                                className="w-full h-9 px-3 bg-white border border-input rounded-md text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-amber-500 focus:border-amber-500 font-medium"
                            >
                                <option value="all">Tất cả mức độ</option>
                                <option value="Dễ">Dễ</option>
                                <option value="Trung bình">Trung bình</option>
                                <option value="Khó">Khó</option>
                                <option value="Rất khó">Rất khó</option>
                            </select>
                        </div>

                    </div>
                </CardContent>
            </Card>

            {/* Data Table display */}
            {isLoading ? (
                <LoadingState />
            ) : error ? (
                <ErrorState message="Lỗi tải dữ liệu nghi lễ quản trị" onRetry={refetch} />
            ) : rituals.length === 0 ? (
                <Card className="border border-dashed border-foreground/10 p-12 text-center">
                    <p className="text-muted-foreground text-sm">
                        Không tìm thấy nghi lễ nào tương thích với điều kiện tìm kiếm.
                    </p>
                    <Button variant="outline" size="sm" onClick={() => { setSearch(""); setSelectedCategoryId("all"); setSelectedDifficulty("all"); }} className="mt-4">
                        Thiết lập lại bộ lọc
                    </Button>
                </Card>
            ) : (
                <div className="space-y-4">
                    <div className="overflow-x-auto rounded-xl border border-foreground/5 shadow-sm bg-white">
                        <table className="w-full text-sm text-left text-slate-700">
                            <thead className="text-xs uppercase bg-slate-50 text-slate-600 border-b border-foreground/5 font-bold">
                                <tr>
                                    <th scope="col" className="px-6 py-4">Tên Nghi Lễ</th>
                                    <th scope="col" className="px-6 py-4">Phân Loại</th>
                                    <th scope="col" className="px-6 py-4">Ngày Âm Lịch</th>
                                    <th scope="col" className="px-6 py-4 text-center">Mức Độ</th>
                                    <th scope="col" className="px-6 py-4 text-center">Thời Gian</th>
                                    <th scope="col" className="px-6 py-4">Ngày Tạo</th>
                                    <th scope="col" className="px-6 py-4 text-right">Thao Tác</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-foreground/5">
                                {rituals.map((ritual) => {
                                    const matchedCategory = categories.find((c) => c.id === ritual.ritualCategoryId);
                                    return (
                                        <tr key={ritual.id} className="hover:bg-slate-50/50 transition-colors duration-150">
                                            <td className="px-6 py-4 font-semibold text-slate-900">
                                                <div className="flex items-center gap-2">
                                                    {ritual.name}
                                                    {ritual.isHot && (
                                                        <span className="inline-flex items-center bg-amber-100 text-amber-800 text-[9px] font-extrabold px-1.5 py-0.5 rounded">
                                                            <Flame className="w-2.5 h-2.5 fill-amber-800" />
                                                        </span>
                                                    )}
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-muted-foreground text-xs font-medium">
                                                {matchedCategory ? matchedCategory.name : "Chưa phân loại"}
                                            </td>
                                            <td className="px-6 py-4 text-xs font-semibold text-slate-800">
                                                {ritual.dateLunar || "Hằng ngày"}
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-bold ${getDifficultyColor(ritual.difficultyLevel)}`}>
                                                    {ritual.difficultyLevel}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-center text-xs font-semibold text-slate-800">
                                                {ritual.timeOfExecution ? `${ritual.timeOfExecution} phút` : "--"}
                                            </td>
                                            <td className="px-6 py-4 text-muted-foreground text-xs">
                                                {new Date(ritual.createdAt).toLocaleDateString("vi-VN")}
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex justify-end items-center gap-2">

                                                    {/* View Detail Link */}
                                                    <Link to={`/ritual/${ritual.id}`}>
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            className="h-8 w-8 p-0 text-slate-500 hover:text-amber-600 hover:bg-slate-100 rounded-lg"
                                                            title="Xem chi tiết"
                                                        >
                                                            <Eye className="w-4 h-4" />
                                                        </Button>
                                                    </Link>

                                                    {/* Edit Link */}
                                                    <Link to={`/admin/rituals/${ritual.id}/edit`}>
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            className="h-8 w-8 p-0 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg"
                                                            title="Sửa thông tin"
                                                        >
                                                            <Edit className="w-4 h-4" />
                                                        </Button>
                                                    </Link>

                                                    {/* Delete Button */}
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => handleDelete(ritual.id, ritual.name)}
                                                        disabled={deleteMutation.isPending && deleteMutation.variables === ritual.id}
                                                        className="h-8 w-8 p-0 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded-lg"
                                                        title="Xóa"
                                                    >
                                                        <Trash2 className="w-4 h-4" />
                                                    </Button>

                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>

                    {/* Pagination Controls */}
                    {totalPages > 1 && (
                        <div className="flex items-center justify-between pt-4 border-t border-foreground/5">
                            <span className="text-xs text-muted-foreground">
                                Đang xem trang <strong className="text-foreground">{page}</strong> trên <strong>{totalPages}</strong>
                            </span>

                            <div className="flex items-center gap-2">
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handlePageChange(page - 1)}
                                    disabled={page === 1}
                                    className="flex items-center gap-1 border-foreground/10 text-muted-foreground h-8"
                                >
                                    <ChevronLeft className="w-3.5 h-3.5" />
                                    Trước
                                </Button>

                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handlePageChange(page + 1)}
                                    disabled={page === totalPages}
                                    className="flex items-center gap-1 border-foreground/10 text-muted-foreground h-8"
                                >
                                    Sau
                                    <ChevronRight className="w-3.5 h-3.5" />
                                </Button>
                            </div>
                        </div>
                    )}

                </div>
            )}

        </div>
    );
};

export default ManageRitualList;

