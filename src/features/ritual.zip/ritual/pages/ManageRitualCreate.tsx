import React from 'react'

const ManageRitualCreate = () => {
    return (
        <div>
            <h1>ManageRitualCreate</h1>
        </div>
    )
}

export default ManageRitualCreate
