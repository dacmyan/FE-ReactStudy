import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useRitualCatalog } from "@/features/ritual/hooks/useRitualCatalog";
import { useRitualCategories } from "@/features/ritual/hooks/useRitualCategories";
import { LoadingState, ErrorState, EmptyState } from "@/shared/components/states/StatusState";
import { Button } from "@/shared/components/ui/button";
import { Card, CardContent } from "@/shared/components/ui/card";
import { Input } from "@/shared/components/ui/input";
import {
  Search,
  Clock,
  Calendar,
  Flame,
  Filter,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  SlidersHorizontal,
  Bookmark
} from "lucide-react";

const RitualCataLog: React.FC = () => {
  // Filter States
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [selectedSort, setSelectedSort] = useState<"NEW" | "OLD" | "NAME">("NEW");
  const [page, setPage] = useState(1);
  const limit = 6; // Limit items per page for better layout grid

  // Debounce search input
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1); // Reset page on search
    }, 400);

    return () => clearTimeout(handler);
  }, [search]);

  // Fetch Categories
  const { data: categoriesData } = useRitualCategories();
  const categories = categoriesData?.data || [];

  // Fetch Rituals Catalog
  // Construct parameters for API query
  const queryParams: any = {
    page,
    limit,
    search: debouncedSearch || undefined,
    ritualCategoryId: selectedCategoryId === "all" ? undefined : selectedCategoryId,
    // The API might accept 'difficultLevel' (from type definition)
    difficultLevel: selectedDifficulty === "all" ? undefined : selectedDifficulty.toLowerCase(),
  };

  const { data: catalogData, isLoading, error, refetch } = useRitualCatalog(queryParams);

  const rituals = catalogData?.data || [];
  const meta = catalogData?.meta;
  const totalPages = meta?.totalPages || 1;

  // Client side sorting if backend does not sort automatically
  const sortedRituals = [...rituals].sort((a, b) => {
    if (selectedSort === "NAME") {
      return a.name.localeCompare(b.name, "vi");
    }
    if (selectedSort === "OLD") {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    // Default NEW (Newest first)
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setPage(newPage);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const resetFilters = () => {
    setSearch("");
    setSelectedCategoryId("all");
    setSelectedDifficulty("all");
    setSelectedSort("NEW");
    setPage(1);
  };

  // Helper to color difficulty level
  const getDifficultyColor = (level: string) => {
    const norm = level.toLowerCase().trim();
    if (norm === "dễ") return "bg-emerald-50 text-emerald-700 border-emerald-200";
    if (norm === "trung bình") return "bg-amber-50 text-amber-700 border-amber-200";
    if (norm === "khó") return "bg-orange-50 text-orange-700 border-orange-200";
    return "bg-rose-50 text-rose-700 border-rose-200";
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8 animate-in fade-in duration-500">

      {/* Page Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">
          <Sparkles className="w-3.5 h-3.5" />
          Không Gian Tâm Linh Việt
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold font-serif text-amber-900 tracking-tight">
          Cẩm Nang Nghi Lễ & Khấn Nguyện
        </h1>
        <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
          Tra cứu, thực hành các nghi lễ cúng kiến cổ truyền chuẩn chỉ của người Việt theo vòng đời, ngày Tết và mùa vụ trong năm.
        </p>
      </div>

      {/* Filter and Search Dashboard */}
      <Card className="border border-foreground/5 shadow-md bg-gradient-to-br from-white to-amber-50/10">
        <CardContent className="pt-6 space-y-6">

          {/* Row 1: Search & Sort */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="Tìm kiếm tên nghi lễ, văn khấn..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 h-11 bg-white border-foreground/10 focus:border-amber-600 focus:ring-amber-500 rounded-lg shadow-sm"
              />
            </div>

            <div className="flex gap-2">
              <div className="relative flex-1">
                <SlidersHorizontal className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <select
                  value={selectedSort}
                  onChange={(e) => setSelectedSort(e.target.value as any)}
                  className="w-full h-11 pl-10 pr-4 bg-white border border-foreground/10 focus:border-amber-600 focus:ring-amber-500 rounded-lg shadow-sm text-sm text-foreground font-medium"
                >
                  <option value="NEW">Mới nhất</option>
                  <option value="OLD">Cũ nhất</option>
                  <option value="NAME">Tên A - Z</option>
                </select>
              </div>
            </div>
          </div>

          {/* Row 2: Category Tags */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold uppercase tracking-wider text-amber-900/70 flex items-center gap-1.5">
              <Bookmark className="w-3.5 h-3.5 text-amber-700" />
              Phân Loại Nghi Lễ
            </label>
            <div className="flex flex-wrap gap-2 overflow-x-auto pb-1 scrollbar-none">
              <button
                onClick={() => { setSelectedCategoryId("all"); setPage(1); }}
                className={`px-4 py-2 rounded-full text-xs font-semibold border transition-all duration-200 whitespace-nowrap ${selectedCategoryId === "all"
                  ? "bg-amber-600 border-amber-600 text-white shadow-md shadow-amber-600/10"
                  : "bg-white hover:bg-amber-50/50 border-foreground/10 text-muted-foreground hover:text-foreground"
                  }`}
              >
                Tất cả
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => { setSelectedCategoryId(cat.id); setPage(1); }}
                  className={`px-4 py-2 rounded-full text-xs font-semibold border transition-all duration-200 whitespace-nowrap ${selectedCategoryId === cat.id
                    ? "bg-amber-600 border-amber-600 text-white shadow-md shadow-amber-600/10"
                    : "bg-white hover:bg-amber-50/50 border-foreground/10 text-muted-foreground hover:text-foreground"
                    }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Row 3: Difficulty Filters */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-foreground/5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900/70 mr-2 flex items-center gap-1">
                <Filter className="w-3.5 h-3.5 text-amber-700" />
                Mức độ chuẩn bị:
              </span>
              {["all", "Dễ", "Trung bình", "Khó", "Rất khó"].map((diff) => (
                <button
                  key={diff}
                  onClick={() => { setSelectedDifficulty(diff); setPage(1); }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all duration-150 ${selectedDifficulty === diff
                    ? "bg-amber-900 border-amber-900 text-white shadow-sm"
                    : "bg-white hover:bg-amber-50/20 border-foreground/10 text-muted-foreground hover:text-foreground"
                    }`}
                >
                  {diff === "all" ? "Tất cả mức độ" : diff}
                </button>
              ))}
            </div>

            {(debouncedSearch || selectedCategoryId !== "all" || selectedDifficulty !== "all" || selectedSort !== "NEW") && (
              <Button
                variant="ghost"
                onClick={resetFilters}
                className="text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg py-1.5 h-auto transition-colors duration-200"
              >
                Xóa tất cả bộ lọc
              </Button>
            )}
          </div>

        </CardContent>
      </Card>

      {/* Ritual Catalog List Display */}
      {isLoading ? (
        <LoadingState />
      ) : error ? (
        <ErrorState message="Lỗi tải danh mục nghi lễ" onRetry={refetch} />
      ) : sortedRituals.length === 0 ? (
        <EmptyState message="Không tìm thấy nghi lễ nào khớp với bộ lọc của bạn" />
      ) : (
        <div className="space-y-8">

          {/* Catalog Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedRituals.map((ritual) => (
              <Link
                key={ritual.id}
                to={`/ritual/${ritual.id}`}
                className="group flex flex-col h-full bg-white rounded-xl border border-foreground/5 hover:border-amber-600/30 overflow-hidden shadow-sm hover:shadow-xl hover:shadow-amber-500/5 hover:-translate-y-1 transition-all duration-300"
              >
                {/* Visual Accent/Header of Card */}
                <div className="relative h-3 w-full bg-gradient-to-r from-amber-600 via-orange-500 to-amber-700"></div>

                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    {/* Header: hot badge + difficulty */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex gap-1.5">
                        {ritual.isHot && (
                          <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-amber-950 shadow-sm animate-pulse">
                            <Flame className="w-2.5 h-2.5 fill-amber-950" />
                            HOT
                          </span>
                        )}
                        <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-semibold ${getDifficultyColor(ritual.difficultyLevel)}`}>
                          {ritual.difficultyLevel}
                        </span>
                      </div>
                      <span className="text-[10px] text-muted-foreground bg-muted/50 px-2 py-0.5 rounded">
                        {ritual.reference ? "Có sách" : "Dân gian"}
                      </span>
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-bold font-serif text-amber-950 group-hover:text-amber-700 transition-colors duration-200 line-clamp-1">
                      {ritual.name}
                    </h3>

                    {/* Description */}
                    <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                      {ritual.description || "Nghi lễ thực hành tâm linh truyền thống, hướng dẫn sắm lễ và văn khấn thành kính."}
                    </p>
                  </div>

                  {/* Metadata and Link Indicator */}
                  <div className="pt-4 border-t border-foreground/5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3 text-muted-foreground font-medium">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-amber-600/70" />
                        {ritual.timeOfExecution ? `${ritual.timeOfExecution}p` : "Tự do"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-amber-600/70" />
                        {ritual.dateLunar || "Hằng ngày"}
                      </span>
                    </div>

                    <span className="text-[11px] font-bold text-amber-700 group-hover:underline flex items-center gap-0.5">
                      Bắt đầu
                      <ChevronRight className="w-3.5 h-3.5 transform group-hover:translate-x-0.5 transition-transform" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-3 pt-6 border-t border-foreground/5">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(page - 1)}
                disabled={page === 1}
                className="flex items-center gap-1.5 border-foreground/10 text-muted-foreground disabled:opacity-40"
              >
                <ChevronLeft className="w-4 h-4" />
                Trước
              </Button>

              <span className="text-xs font-semibold text-muted-foreground">
                Trang <strong className="text-foreground">{page}</strong> trên <strong>{totalPages}</strong>
              </span>

              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(page + 1)}
                disabled={page === totalPages}
                className="flex items-center gap-1.5 border-foreground/10 text-muted-foreground disabled:opacity-40"
              >
                Sau
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          )}

        </div>
      )}

    </div>
  );
};

export default RitualCataLog;

